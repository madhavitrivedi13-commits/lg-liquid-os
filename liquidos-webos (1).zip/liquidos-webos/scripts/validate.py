#!/usr/bin/env python3
"""Static checks only (no TV, no SDK). Run from anywhere: python3 scripts/validate.py"""
import json,os,re,sys
os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..'))
a=json.load(open('appinfo.json'));bad=[]
for k in ['id','version','vendor','type','main','title','icon']:
    if k not in a:bad.append('missing '+k)
if not re.fullmatch(r'[a-z0-9.\-]+',a['id']):bad.append('bad id')
if not re.fullmatch(r'\d+\.\d+\.\d+',a['version']):bad.append('bad version')
if 'bgImage' in a:bad.append('bgImage is the launcher preview image, not the splash')
if 'application.launcher' not in a.get('requiredACG',[]):bad.append('requiredACG needs application.launcher')
for k in ['main','icon','largeIcon','splashBackground']:
    if k in a and not os.path.isfile(a[k]):bad.append('missing file '+a[k])
for f in ['css/liquid.css','js/platform.js','js/config.js','js/app.js','config.json']:
    if not os.path.isfile(f):bad.append('missing '+f)
json.load(open('config.json'))
h=open('index.html').read()
for r in re.findall(r'(?:src|href)="([^"]+)"',h):
    if not os.path.isfile(r) and r!='vendor/webOSTV.js':bad.append('index.html refs missing '+r)
print('vendor/webOSTV.js:','present' if os.path.isfile('vendor/webOSTV.js') else 'MISSING (add the official LG file)')
print('PROBLEMS:',bad if bad else 'none');sys.exit(1 if bad else 0)
