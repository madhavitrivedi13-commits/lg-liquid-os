#!/usr/bin/env bash
# Builds the .ipk with LG's official webOS TV CLI (ares-package). Refuses to build without the official webOSTV.js.
set -e
cd "$(dirname "$0")/.."
[ -f vendor/webOSTV.js ] || { echo "Missing vendor/webOSTV.js (official LG file). See README step 1."; exit 1; }
command -v ares-package >/dev/null || { echo "ares-package not found: npm install -g @webos-tools/cli"; exit 1; }
rm -f vendor/PLACE_webOSTV.js_HERE.txt
mkdir -p dist
ares-package . -o dist
ls -l dist/*.ipk
