'use strict';

const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

/* ===== PLATFORM ADAPTER: the only place that touches webOS. Swap for Magic Remote / other services later. ===== */
const P={
  on:!!(window.webOS&&window.webOS.service&&window.webOS.service.request),
  req(uri,method,parameters={}){return new Promise((ok,no)=>{try{webOS.service.request(uri,{method,parameters,onSuccess:ok,onFailure:no})}catch(e){no(e)}})},
  launch:id=>P.req('luna://com.webos.applicationManager','launch',{id}),
  loadStatus:id=>P.req('luna://com.webos.applicationManager','getAppLoadStatus',{appId:id}),
  platformBack:()=>{try{if(window.webOS&&webOS.platformBack){webOS.platformBack();return true}}catch(e){}return false}
};
/* Candidate IDs: best-known, NOT verified. LG documents no API to list third-party apps; availability is learned only by launching. */
const CAT=[['youtube.leanback.v4','YouTube','#ff2d2d','▶'],['netflix','Netflix','#e50914','N'],['amazon','Prime Video','#00a8e1','P'],['com.disney.disneyplus-prod','Disney+','#2a5bd7','D+'],['com.apple.appletv','Apple TV','#9aa0aa','tv'],['spotify-beta','Spotify','#1ed760','S'],['hulu','Hulu','#1ce783','h'],['plex','Plex','#e5a00d','›'],['com.webos.app.livetv','Live TV','#ffb020','TV'],['com.webos.app.browser','Web Browser','#4aa3ff','◎'],['com.webos.app.igallery','Photo & Video','#b46bff','▣'],['com.webos.app.mediadiscovery','Media Player','#34d1b6','♪'],['com.palm.app.settings','LG Settings','#8892a6','⚙']].map(([id,name,c,g])=>({id,name,c,g}));
const INP=[['com.webos.app.hdmi1','HDMI 1','HDMI_1'],['com.webos.app.hdmi2','HDMI 2','HDMI_2'],['com.webos.app.hdmi3','HDMI 3','HDMI_3'],['com.webos.app.hdmi4','HDMI 4','HDMI_4'],['com.webos.app.externalinput.av1','AV','AV_1'],['com.webos.app.livetv','Live TV','']];
