'use strict';
/* ===== STATE + LOCAL STORAGE (no network) ===== */
const LS={get(){try{return JSON.parse(localStorage.getItem('liquidos.v1'))||{}}catch(e){return{}}},set(o){try{localStorage.setItem('liquidos.v1',JSON.stringify(o))}catch(e){}}};
const sv=LS.get();
const S={view:'home',tab:0,home:Array.isArray(sv.home)?sv.home:[...DEFHOME],dock:(sv.dock&&sv.dock.length===6)?sv.dock:[...DEFDOCK],th:{...DEF,...sv.th},idle:sv.idle??300,rec:[],inst:null,found:[],derr:null,menu:null,pop:false,mv:null,inputs:{},check:false,ss:false,boot:true,cur:null,ret:null};
const save=()=>LS.set({home:S.home,dock:S.dock,th:S.th,idle:S.idle});
function applyTheme(){const t=S.th,r=document.documentElement.style,h=t.glassTint.slice(1);r.setProperty('--acc',t.accent);r.setProperty('--tint',[0,2,4].map(i=>parseInt(h.substr(i,2),16)).join(','));r.setProperty('--ga',t.glassOpacity);$('#stage').style.background=WALL[t.wallpaper]||WALL.midnight}
function A(id){const c=CAT.find(x=>x.id===id),f=S.found.find(x=>x.id===id);return c?{...c,icon:f&&f.icon}:{id,name:(f&&f.title)||id,c:'#8892a6',g:((f&&f.title)||'?')[0],icon:f&&f.icon}}
const libIds=()=>[...CAT.map(c=>c.id),...S.found.map(f=>f.id).filter(i=>!CAT.some(c=>c.id===i))];

/* ===== REAL LAUNCH ===== */
let tt;function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('on');clearTimeout(tt);tt=setTimeout(()=>t.classList.remove('on'),5000)}
async function launch(id,name,track=true){
  if(!P.on)return toast(`Can't launch ${name}: this is a browser preview with no webOS APIs. Launching works only when LIQUID OS is packaged and installed on the TV.`);
  if(S.inst&&!S.inst.has(id))return toast(`${name} is not installed on this TV.`);
  try{await P.launch(id);if(track){S.rec=[{id,t:Date.now()},...S.rec.filter(r=>r.id!==id)]}}
  catch(e){toast(`Couldn't launch ${name}: ${(e&&(e.errorText||e.message))||'unknown error'}`)}
}
/* LG documents no API that lists installed third-party apps, so there is no discovery: apps are launched by ID and the real result is shown. */
async function discover(){}
async function loadInputs(){}
async function diagnose(){S.diag={};for(const c of CAT){try{S.diag[c.id]=JSON.stringify(await P.loadStatus(c.id))}catch(e){S.diag[c.id]='error: '+((e&&(e.errorText||e.message))||'unknown')}}S.check=true;render(S.cur)}

/* ===== VIEWS ===== */
const icon=a=>`<div class="ic" style="--c:${a.c}"><b>${esc(a.g)}</b>${a.icon?`<img src="${esc(a.icon)}" onerror="this.remove()">`:''}</div>`;
const tile=(id,src,key,extra='')=>{const a=A(id),mv=S.mv&&S.mv.id===id&&key[0]!=='l'?' mvt':'';return `<div class="t f${mv}" data-k="${key}" data-a="launch:${id}" data-m="${id}:${src}" data-n="${esc(a.name)}" data-c="${a.c}">${icon(a)}<span>${esc(a.name)}</span>${extra}</div>`};
const pill=(k,a,t,cls='')=>`<div class="pill gl f ${cls}" data-k="${k}" data-a="${a}">${t}</div>`;
const VIEW={
home:()=>`<div class="top"><div><div class="eye">LG LIQUID OS 1.0</div><h1 id="nm"></h1><div id="sb"></div></div><div class="acts">${['Library','Recents','Inputs','Settings'].map(x=>pill('p:'+x,'nav:'+x,x)).join('')}</div></div>
<div class="grid ${S.mv?'mvg':''}">${S.home.length?S.home.map(id=>tile(id,'home','h:'+id)).join(''):'<div class="empty">Home is empty. Add apps from the Library.</div>'}</div>
<div class="dock gl ${S.mv?'mvg':''}">${S.dock.map(id=>tile(id,'dock','d:'+id)).join('')}</div>
<div class="hint">← ↑ → ↓ Navigate · Enter = OK (hold for options) · Esc = Back · Home · M = Menu</div>`,
library:()=>{const ids=libIds();return `<div class="hd">${pill('p:home','nav:Home','‹ Home')}<h2>App Library</h2></div><p class="note">Candidate apps by ID · webOS reports real availability only when you launch</p>
<div class="grid" style="height:760px">${ids.map(id=>{const inH=S.home.includes(id),miss=S.inst&&!S.inst.has(id);return tile(id,'lib','l:'+id,(inH?'<div class="badge">On Home</div>':'')+(miss?'<div class="badge">Not installed</div>':''))}).join('')}</div>`},
recents:()=>`<div class="hd">${pill('p:home','nav:Home','‹ Home')}<h2>Recent Apps</h2>${pill('p:ca','closeall','Close All')}</div>
<p class="note">Apps opened from LIQUID OS. Close only removes a card from this list — it never stops another app.</p>
<div class="rail">${S.rec.length?S.rec.map(r=>{const a=A(r.id);return `<div class="col"><div class="card2 gl f" data-k="r:${r.id}" data-a="launch:${r.id}" data-n="${esc(a.name)}" data-c="${a.c}">${icon(a)}<h3>${esc(a.name)}</h3><small>Opened ${new Date(r.t).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})}</small></div>${pill('x:'+r.id,'close:'+r.id,'Close')}</div>`}).join(''):'<div class="empty">Nothing yet. Apps you launch from here appear as cards.</div>'}</div>`,
settings:()=>`<div class="hd">${pill('p:home','nav:Home','‹ Home')}<h2>Settings</h2></div><div class="set"><div class="tabs">${TABS.map((t,i)=>`<div class="tab f ${i===S.tab?'sel':''}" data-k="t:${i}" data-a="tab:${i}">${t}</div>`).join('')}</div><div class="panel gl">${panel()}</div></div>`
};
function panel(){const n=TABS[S.tab],t=S.th;
 if(S.tab<4)return `<h2>${n}</h2><p>${n} is controlled by LG webOS. LIQUID OS cannot change it and does not imitate it. Use the system settings.</p>${pill('b:sys','sys','Open LG Settings')}`;
 if(S.tab===4)return `<h2>Inputs</h2><p>Switch to HDMI, AV or Live TV. Connection status appears only when webOS reports it.</p>${pill('b:inp','nav:Inputs','Open Inputs')}`;
 if(S.tab===5)return `<h2>Personalisation</h2><p>Grid: ${t.columns} columns · Dock: ${t.dock} apps (fixed in 1.0). Reorder with hold OK → Move.</p><div class="row">${pill('b:r1','rsthome','Reset Home order')}${pill('b:r2','rstdock','Restore default dock')}</div>`;
 if(S.tab===6){const sw=(a,c,cur)=>`<div class="sw f ${cur===c?'sel':''}" data-k="${a}:${c}" data-a="${a}:${c}" style="background:${c}"></div>`;
  return `<h2>Theme · ${t.name}</h2><div class="row"><label>Accent</label>${['#7aa2ff','#ff5d8f','#34d1b6','#ffb020','#b46bff','#ff6a3d'].map(c=>sw('acc',c,t.accent)).join('')}</div><div class="row"><label>Glass tint</label>${['#ffffff','#bcd4ff','#ffd9bf','#d6bfff'].map(c=>sw('tint',c,t.glassTint)).join('')}</div><div class="row"><label>Wallpaper</label>${Object.keys(WALL).map(w=>pill('w:'+w,'wall:'+w,w,t.wallpaper===w?'sel':'')).join('')}</div><p>config.json — applied live, no UI rebuild:</p><pre>${esc(JSON.stringify(t,null,2))}</pre>${pill('b:rt','rstheme','Reset theme')}`}
 if(S.tab===7)return `<h2>Screensaver</h2><p>Clock screensaver after idle time. Runs only while LIQUID OS is in the foreground.</p><div class="row">${[[30,'30 sec'],[60,'1 min'],[300,'5 min'],[600,'10 min'],[1800,'30 min'],[0,'Off']].map(([s,l])=>pill('i:'+s,'idle:'+s,l,S.idle===s?'sel':'')).join('')}</div>${pill('b:pv','preview','Preview now')}`;
 return `<h2>About LG LIQUID OS</h2><p>Version 1.0 · by Pranikk<br>Target: LG webOS 25 · software 10.1.8-56<br>Runtime: ${P.on?'webOS APIs detected':'browser preview — no webOS APIs, so app launching is disabled'}<br>Not an installed webOS app until packaged. No analytics, telemetry or network calls from LIQUID OS; settings stay in local storage. LIQUID OS does not and cannot disable LG system-level telemetry or ads.</p>${pill('b:ck','check','Check app IDs (raw webOS replies)')}${S.check&&S.diag?`<p style="margin-top:24px">Raw getAppLoadStatus replies:</p><div class="ls">${CAT.map(c=>`<div>${esc(c.name)}: ${esc(S.diag[c.id])}</div>`).join('')}</div>`:''}`}
const popHTML=()=>`<div class="scrim"><div class="card gl"><h3>Inputs</h3><small>${P.on?'Connection status is not available to this app':'Browser preview: switching disabled'}</small>${INP.map(([id,n])=>`<div class="mi f" data-k="n:${id}" data-a="input:${id}:${n}"><span>${n}</span><i>${S.inputs[id]||'Status unavailable'}</i></div>`).join('')}</div></div>`;
const menuHTML=()=>{const [id,src]=S.menu.split(':'),a=A(id),inH=S.home.includes(id);const it=[['Open','mopen:'+id]];if(src!=='lib')it.push(['Move',`move:${src}:${id}`]);if(src==='home'||(src==='lib'&&inH))it.push(['Remove from Home','rmhome:'+id]);if(src==='lib'&&!inH)it.push(['Add to Home','addhome:'+id]);return `<div class="scrim"><div class="card gl"><h3>${esc(a.name)}</h3><small>Removing from Home never uninstalls an app</small>${it.map(([l,x],i)=>`<div class="mi f" data-k="m:${i}" data-a="${x}"><span>${l}</span></div>`).join('')}</div></div>`};

/* ===== RENDER + FOCUS ===== */
const root=()=>S.menu?$('#menu'):S.pop?$('#pop'):$('#v');
const cur=()=>$('.on',root());
function render(key){$('#v').innerHTML=VIEW[S.view]();$('#pop').innerHTML=S.pop?popHTML():'';$('#menu').innerHTML=S.menu?menuHTML():'';const r=root();focus($(`[data-k="${CSS.escape(key||S.cur||'')}"]`,r)||$('.t',r)||$('.f',r));$('#mode').style.display=P.on?'none':'block'}
function focus(el){if(!el)return;$$('.on').forEach(x=>x.classList.remove('on'));el.classList.add('on');S.cur=el.dataset.k;el.scrollIntoView({block:'nearest',inline:'nearest'});
 if(el.dataset.c)document.documentElement.style.setProperty('--g',el.dataset.c);
 const nm=$('#nm');if(nm&&el.dataset.n){nm.textContent=el.dataset.n;$('#sb').textContent=S.mv?'Moving — arrows move · OK places · Back cancels':(S.inst&&el.dataset.m&&!S.inst.has(el.dataset.m.split(':')[0])?'Not installed on this TV':'OK to open · hold OK for options')}}
function nav(dx,dy){const c=cur();if(!c)return;const list=$$('.f',root()),r0=c.getBoundingClientRect(),cx=r0.x+r0.width/2,cy=r0.y+r0.height/2;let best=null,bs=1e9;
 for(const el of list){if(el===c)continue;const r=el.getBoundingClientRect(),vx=r.x+r.width/2-cx,vy=r.y+r.height/2-cy;if(dx&&vx*dx<=8)continue;if(dy&&vy*dy<=8)continue;const s=dx?Math.abs(vx)+Math.abs(vy)*3:Math.abs(vy)+Math.abs(vx)*3;if(s<bs){bs=s;best=el}}if(best)focus(best)}

/* ===== ACTIONS ===== */
function closeMenu(){S.menu=null;render(S.ret)}
function act(el){const [a,x,y]=el.dataset.a.split(':'),t=S.th;
 switch(a){
 case'launch':launch(x,A(x).name);break;
 case'mopen':S.menu=null;render(S.ret);launch(x,A(x).name);break;
 case'nav':if(x==='Inputs'){S.ret=S.cur;S.pop=true;render('n:'+INP[0][0]);loadInputs()}else{S.view=x.toLowerCase();render()}break;
 case'input':S.pop=false;render(S.ret);launch(x,y,false);break;
 case'move':{const k=(x==='home'?'h:':'d:')+y;S.menu=null;S.mv={list:x,id:y,orig:[...S[x]]};render(k);break}
 case'rmhome':S.home=S.home.filter(i=>i!==x);S.menu=null;save();render(S.ret);toast('Removed from Home. The app is still installed.');break;
 case'addhome':if(!S.home.includes(x))S.home.push(x);S.menu=null;save();render(S.ret);toast('Added to Home');break;
 case'close':{const k=$$('[data-k^="x:"]').map(e=>e.dataset.k);const i=k.indexOf('x:'+x);S.rec=S.rec.filter(r=>r.id!==x);const n=S.rec[Math.min(i,S.rec.length-1)];render(n?'x:'+n.id:'p:home');break}
 case'closeall':S.rec=[];render('p:home');toast('Cleared the LIQUID OS recent list. Other apps were not affected.');break;
 case'tab':S.tab=+x;render('t:'+x);break;
 case'sys':launch('com.palm.app.settings','LG Settings',false);break;
 case'rsthome':S.home=[...DEFHOME];save();render(S.cur);toast('Home order reset');break;
 case'rstdock':S.dock=[...DEFDOCK];save();render(S.cur);toast('Dock restored');break;
 case'acc':t.accent=x;save();applyTheme();render(S.cur);break;
 case'tint':t.glassTint=x;save();applyTheme();render(S.cur);break;
 case'wall':t.wallpaper=x;save();applyTheme();render(S.cur);break;
 case'rstheme':S.th={...DEF};save();applyTheme();render(S.cur);break;
 case'idle':S.idle=+x;save();render(S.cur);break;
 case'preview':showSS();break;
 case'check':if(!P.on){toast('Needs webOS: this preview cannot query apps.');break}diagnose();break}}
function openMenu(s){S.ret=S.cur;S.menu=s;render('m:0')}
function back(){if(S.menu)closeMenu();else if(S.pop){S.pop=false;render(S.ret)}else if(S.view!=='home'){S.view='home';render()}else P.platformBack()}
function goHome(){S.menu=null;S.pop=false;S.view='home';render()}
function mvKey(k){const m=S.mv,L=S[m.list],i=L.indexOf(m.id);let j=i;
 if(k==='L')j=i-1;else if(k==='R')j=i+1;else if(k==='U'&&m.list==='home')j=i-6;else if(k==='D'&&m.list==='home')j=Math.min(i+6,L.length-1);
 else if(k==='OK'){S.mv=null;save();render(S.cur);return toast('Placed')}
 else if(k==='BACK'){S[m.list]=m.orig;S.mv=null;render(S.cur);return toast('Move cancelled')}else return;
 if(j<0||j>=L.length||j===i)return;L.splice(i,1);L.splice(j,0,m.id);render(S.cur)}
function press(k){if(S.mv)return mvKey(k);
 if(k==='BACK')return back();if(k==='HOME')return goHome();
 if(k==='MENU'){const c=cur();if(c&&c.dataset.m)return openMenu(c.dataset.m);if(!S.menu&&!S.pop){S.view='settings';render()}return}
 if(k==='OK'){const c=cur();if(c)act(c);return}
 nav(k==='L'?-1:k==='R'?1:0,k==='U'?-1:k==='D'?1:0)}

/* ===== REMOTE INPUT (keyboard sim; webOS remote keycodes: Back 461, Menu/Options 457). Magic Remote pointer = mouse events. ===== */
const K={37:'L',38:'U',39:'R',40:'D',13:'OK',27:'BACK',8:'BACK',461:'BACK',36:'HOME',1537:'HOME',77:'MENU',93:'MENU',457:'MENU'};
let last=Date.now(),holdT,held=false,swallow=false;
function wake(){last=Date.now();if(S.boot){endBoot();return true}if(S.ss){hideSS();return true}return false}
addEventListener('keydown',e=>{const k=K[e.keyCode];if(!k)return;e.preventDefault();if(k==='OK'&&e.repeat)return;if(wake()){swallow=true;return}swallow=false;
 if(k==='OK'){held=false;holdT=setTimeout(()=>{held=true;const c=cur();if(c&&c.dataset.m&&!S.mv&&!S.menu&&!S.pop)openMenu(c.dataset.m)},550);return}press(k)});
addEventListener('keyup',e=>{if(K[e.keyCode]!=='OK')return;clearTimeout(holdT);if(swallow||held){swallow=false;return}press('OK')});
document.addEventListener('mouseover',e=>{const el=e.target.closest('.f');if(el&&!S.mv&&root().contains(el)&&!el.classList.contains('on'))focus(el)});
document.addEventListener('mousemove',()=>{if(S.ss)wake();else last=Date.now()});
document.addEventListener('click',e=>{if(wake())return;if(e.target.classList.contains('scrim'))return back();const el=e.target.closest('.f');if(el&&root().contains(el)&&!S.mv){focus(el);act(el)}});
document.addEventListener('contextmenu',e=>{const el=e.target.closest('.f[data-m]');if(el&&!S.mv&&!S.menu&&!S.pop){e.preventDefault();focus(el);openMenu(el.dataset.m)}});

/* ===== SCREENSAVER ===== */
const rnd=(a,b)=>a+Math.random()*(b-a);let dr;
function tick(){const d=new Date();$('#ct').textContent=d.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',hour12:false});$('#cd').textContent=d.toLocaleDateString([],{weekday:'long',day:'numeric',month:'long'})}
function showSS(){S.ss=true;S.menu=null;S.pop=false;tick();$('#ss').classList.add('on');const m=()=>$('#clk').style.transform=`translate(${rnd(-300,300)}px,${rnd(-150,150)}px)`;m();dr=setInterval(m,25000)}
function hideSS(){S.ss=false;clearInterval(dr);$('#ss').classList.remove('on');render(S.cur)}
setInterval(()=>{if(S.ss)tick();else if(!S.boot&&S.idle&&Date.now()-last>S.idle*1000)showSS()},1000);

/* ===== BOOT: cinematic startup, once per app launch ===== */
function endBoot(){if(!S.boot)return;S.boot=false;$('#st').classList.add('out');setTimeout(()=>$('#st').remove(),1300)}
function fit(){const s=Math.min(innerWidth/1920,innerHeight/1080);$('#stage').style.transform=`translate(${-960*s}px,${-540*s}px) scale(${s})`}
function loadConfig(){try{const x=new XMLHttpRequest();x.open('GET','config.json');x.onload=()=>{try{const c=JSON.parse(x.responseText);if(c&&c.wallpaper&&!WALL[c.wallpaper])delete c.wallpaper;S.th={...DEF,...c,...sv.th};applyTheme();render(S.cur)}catch(e){}};x.onerror=()=>{};x.send()}catch(e){}}
addEventListener('resize',fit);fit();applyTheme();loadConfig();$('#mode').textContent='Browser preview — webOS APIs unavailable, app launching disabled';
render();discover();setTimeout(endBoot,5600);
