'use strict';
const WALL={midnight:'radial-gradient(120% 90% at 50% 0%,#0c1330,#03040a 70%)',abyss:'radial-gradient(120% 90% at 20% 0%,#052a35,#02060a 70%)',ember:'radial-gradient(120% 90% at 80% 0%,#2e1208,#080304 70%)',nebula:'radial-gradient(120% 90% at 50% 0%,#241043,#06030f 70%)'};
const DEF={name:'Aurora',columns:6,dock:6,wallpaper:'midnight',accent:'#7aa2ff',glassTint:'#ffffff',glassOpacity:.09};
const DEFHOME=['youtube.leanback.v4','netflix','amazon','com.disney.disneyplus-prod','com.apple.appletv','spotify-beta','hulu'];
const DEFDOCK=['com.webos.app.livetv','com.webos.app.browser','com.webos.app.igallery','com.webos.app.mediadiscovery','com.palm.app.settings','plex'];
const TABS=['Display','Sound','Network','Bluetooth','Inputs','Personalisation','Theme','Screensaver','About LG LIQUID OS'];
