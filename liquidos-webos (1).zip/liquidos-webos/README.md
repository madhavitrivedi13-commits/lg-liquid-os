# LG LIQUID OS 1.0 — webOS TV project

STATUS: complete source project. **No .ipk has been built** (authoring environment has no `ares-cli` and no network)
and **nothing has been tested on an LG TV**. The official `vendor/webOSTV.js` is **not included**; you must add it.

## Android packaging: not possible
webOS is not Android. APK files cannot be installed on LG webOS, and apps are not converted from Android.
The only supported sideload path is a webOS .ipk (HTML/CSS/JS web app) built with LG's webOS TV CLI and installed via Developer Mode.

## Structure
```
appinfo.json     id com.pranikk.liquidos, 1920x1080, requiredACG application.launcher
index.html       shell + startup/screensaver markup
css/liquid.css   Liquid Glass styling
js/platform.js   ONLY file that calls webOS (adapter "P"), app catalog, inputs list
js/config.js     wallpapers, default theme, default Home/Dock, settings tabs
js/app.js        UI, spatial focus navigation, remote keys, launcher logic
config.json      theme config (read locally; falls back to built-in defaults)
assets/          icon80.png (80x80), icon130.png (130x130), splash.png (1920x1080)
vendor/          put the official webOSTV.js here
scripts/         build.sh (refuses to build without webOSTV.js), validate.py
```

## What the official docs say (checked against LG's webOS TV developer site)
- appinfo.json: `id, version, vendor, type("web"), main, title, icon (80x80), largeIcon (130x130), resolution, splashBackground, disableBackHistoryAPI, requiredACG` are documented. `bgImage` is a launcher *preview* image, so it was removed (it was wrongly the splash).
- Luna calls need Access Control Groups declared in appinfo.json (`requiredACG`). `application.launcher` is documented for launching apps.
- `luna://com.webos.applicationManager` `launch {id}` is documented. `getAppLoadStatus {appId}` (webOS TV 4.0+) is documented for checking whether an app exists.
- **LG states no API lists installed third-party apps.** So LIQUID OS does NOT discover apps: it launches by ID and shows webOS's real success/error. (The earlier `listApps` and `eim` calls were removed; they are not in LG's public docs.)
- `webOS.platformBack()` is documented; Back on Home calls it (needed because `disableBackHistoryAPI` is true).

## Steps to a real .ipk and install
1. Download the official webOSTV.js from LG (webostv.developer.lge.com, webOSTV.js reference/download). Save the file as `vendor/webOSTV.js`. Do not edit or recreate it.
2. `npm install -g @webos-tools/cli`
3. TV: install "Developer Mode" app (LG Content Store), sign in with an LG developer account, Dev Mode ON, Key Server ON; note IP and passphrase.
4. ```
   python3 scripts/validate.py
   ares-setup-device --add lgtv --info "{'host':'TV_IP','port':'9922','username':'prisoner'}"
   ares-novacom --device lgtv --getkey
   ./scripts/build.sh
   ares-install --device lgtv dist/com.pranikk.liquidos_1.0.0_all.ipk
   ares-launch  --device lgtv com.pranikk.liquidos
   ares-inspect --device lgtv --app com.pranikk.liquidos --open
   ```
5. In the app: Settings -> About -> "Check app IDs" shows raw webOS replies; send me those plus any errors.
Dev Mode sessions expire (about 50 hours) and must be extended in the Developer Mode app.

## Verified (headless desktop Chromium + a test-only mock of webOS.service.request; NOT a TV)
Boot once per launch, Home/dock, keyboard nav, hold-OK menu, Move/place/cancel, Library, Recents, Settings, theme switching,
launch call pattern (`launch {id}`), error toast on failure, `platformBack` on Home Back, diagnostics view.
The mock proves only my call pattern, not LG behaviour.

## NOT verified (needs your TV)
- `ares-package` accepting this appinfo.json; the exact `getAppLoadStatus` reply format (shown raw, not interpreted).
- Whether `application.launcher` ACG is enough for `launch` via `webOS.service.request` on 10.1.8-56, and whether retail firmware allows launching each app.
- Every catalog app ID; `com.palm.app.settings`, `com.webos.app.hdmi1-4`, `externalinput.av1`, `livetv` (community-documented, not in LG's public reference).
- Back 461 / Menu 457 key codes, Magic Remote pointer, local `config.json` loading on-device, splash display.

## Privacy
No analytics, telemetry or network calls. Settings in local storage. Does not and cannot disable LG system telemetry or ads.
